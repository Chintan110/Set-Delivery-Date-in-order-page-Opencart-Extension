<?php
class ControllerExtensionModuleDelivery extends Controller {
	private $error = array();
	public function index() {
		$this->load->language('extension/module/delivery');
		$this->document->setTitle($this->language->get('heading_title'));
		$this->load->model('setting/setting');
		if ($this->request->server['REQUEST_METHOD'] == 'POST') {
			// Deactivate Date
			// $module_deldatetime_datedeactive = '';
			// foreach ($this->request->post['module_deldatetime_datedeactive'] as $value) {
			// 	$module_deldatetime_datedeactive .= $value['de_date'] . ', ';
			// }
			// $this->request->post['module_deldatetime_datedeactive'] = $module_deldatetime_datedeactive;

			// Deactivate week day
			$module_deldatetime_week = '';
			foreach ($this->request->post['module_deldatetime_week'] as $key => $value) {
				$module_deldatetime_week .= $value . ', ';
			}
			$this->request->post['module_deldatetime_week'] = $module_deldatetime_week;

			// Deactivate shipping_method
			$module_deldatetime_shipping_method = '';
			foreach ($this->request->post['module_deldatetime_shipping_method'] as $key => $value) {
				$module_deldatetime_shipping_method .= $value . ', ';
			}
			$this->request->post['module_deldatetime_shipping_method'] = $module_deldatetime_shipping_method;

			$this->model_setting_setting->editSetting('module_deldatetime', $this->request->post);
			$this->session->data['success'] = $this->language->get('text_success');
			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true));
		}
		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		$data['breadcrumbs'] = array();
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true)
		);
		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/module/delivery', 'user_token=' . $this->session->data['user_token'], true)
		);
		$data['action'] = $this->url->link('extension/module/delivery', 'user_token=' . $this->session->data['user_token'], true);
		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);
		if (isset($this->request->post['module_deldatetime_status'])) {
			$data['module_deldatetime_status'] = $this->request->post['module_deldatetime_status'];
		} else {
			$data['module_deldatetime_status'] = $this->config->get('module_deldatetime_status');
		}
		if (isset($this->request->post['module_deldatetime_week'])) {
			$data['module_deldatetime_week'] = $this->request->post['module_deldatetime_week'];
		} else {
			$data['module_deldatetime_week'] = array_filter(explode(', ',$this->config->get('module_deldatetime_week')));
		}
		if (isset($this->request->post['module_deldatetime_datedeactive'])) {
			$data['module_deldatetime_datedeactive'] = $this->request->post['module_deldatetime_datedeactive'];
		} else {
			$data['module_deldatetime_datedeactive'] = $this->config->get('module_deldatetime_datedeactive');
		}
		if (isset($this->request->post['module_deldatetime_future_datedeactive_date'])) {
			$data['module_deldatetime_future_datedeactive_date'] = $this->request->post['module_deldatetime_future_datedeactive_date'];
		} else {
			$data['module_deldatetime_future_datedeactive_date'] = $this->config->get('module_deldatetime_future_datedeactive_date');
		}
		if (isset($this->request->post['module_deldatetime_timeslot_error_label'])) {
			$data['module_deldatetime_timeslot_error_label'] = $this->request->post['module_deldatetime_timeslot_error_label'];
		} else {
			$data['module_deldatetime_timeslot_error_label'] = $this->config->get('module_deldatetime_timeslot_error_label');
		}
		if (isset($this->request->post['module_deldatetime_max_date'])) {
			$data['module_deldatetime_max_date'] = $this->request->post['module_deldatetime_max_date'];
		} else {
			$data['module_deldatetime_max_date'] = $this->config->get('module_deldatetime_max_date');
		}
		if (isset($this->request->post['module_deldatetime_time_start'])) {
			$data['module_deldatetime_time_start'] = $this->request->post['module_deldatetime_time_start'];
		} else {
			$data['module_deldatetime_time_start'] = $this->config->get('module_deldatetime_time_start');
		}
		if (isset($this->request->post['module_deldatetime_time_end'])) {
			$data['module_deldatetime_time_end'] = $this->request->post['module_deldatetime_time_end'];
		} else {
			$data['module_deldatetime_time_end'] = $this->config->get('module_deldatetime_time_end');
		}
		if (isset($this->request->post['module_deldatetime_multi_datetext'])) {
			$data['module_deldatetime_multi_datetext'] = $this->request->post['module_deldatetime_multi_datetext'];
		} else {
			$data['module_deldatetime_multi_datetext'] = $this->config->get('module_deldatetime_multi_datetext');
		}
		// if (isset($this->request->post['module_deldatetime_multi_timetext'])) {
		// 	$data['module_deldatetime_multi_timetext'] = $this->request->post['module_deldatetime_multi_timetext'];
		// } else {
		// 	$data['module_deldatetime_multi_timetext'] = $this->config->get('module_deldatetime_multi_timetext');
		// }
		if (isset($this->request->post['module_deldatetime_multi_dateerror'])) {
			$data['module_deldatetime_multi_dateerror'] = $this->request->post['module_deldatetime_multi_dateerror'];
		} else {
			$data['module_deldatetime_multi_dateerror'] = $this->config->get('module_deldatetime_multi_dateerror');
		}
		// if (isset($this->request->post['module_deldatetime_multi_timeerror'])) {
		// 	$data['module_deldatetime_multi_timeerror'] = $this->request->post['module_deldatetime_multi_timeerror'];
		// } else {
		// 	$data['module_deldatetime_multi_timeerror'] = $this->config->get('module_deldatetime_multi_timeerror');
		// }

		$this->load->model('setting/extension');

			$data['shipping_methods'] = $this->model_setting_extension->getExtensions('shipping');

		if (isset($this->request->post['module_deldatetime_shipping_method'])) {
			$data['module_deldatetime_shipping_method'] = $this->request->post['module_deldatetime_shipping_method'];
		} else {
			$data['module_deldatetime_shipping_method'] = array_filter(explode(', ',$this->config->get('module_deldatetime_shipping_method')));
		}

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		$this->response->setOutput($this->load->view('extension/module/delivery', $data));
	}
}