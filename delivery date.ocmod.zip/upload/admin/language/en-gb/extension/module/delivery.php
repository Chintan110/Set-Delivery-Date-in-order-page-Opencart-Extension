<?php
// Heading
$_['heading_title']    = 'Delivery Date & Time';
// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Delivery module!';
$_['text_edit']        = 'Edit Delivery Module';
// tabs
$_['tab_label']        = 'Label';
$_['tab_date']         = 'Date';
$_['tab_shipping']     = 'Shipping Methods';
// Entry
$_['entry_status']     = 'Status';
$_['entry_module_deldatetime_week']     = 'Weekend Leave';
$_['entry_deactivate_date']     = 'Deactivate Date';
$_['entry_future_deactivate_date'] = 'Holiday Date and it formate (m/d/Y)';
$_['entry_future_max_date'] = 'Max day of Delivery';
$_['entry_delivery_date_label'] = 'Delivery Date Label';
$_['entry_delivery_time_label'] = 'Delivery Time Label';
$_['entry_delivery_date_error'] = 'Delivery Date Error';
$_['entry_delivery_time_error'] = 'Delivery Time Error';
$_['entry_deactivate_time_start'] = 'Delivery Time Slot Start';
$_['entry_deactivate_time_end'] = 'Delivery Time Slot End';
$_['entry_delivery_timeslot_error_label'] = 'Delivery Time Slot Error lable';
$_['entry_module_shipping_method'] = 'Shipping Methods';
// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Delivery module!';